const categoryButtons = document.querySelectorAll('.category');
categoryButtons.forEach(button => button.addEventListener('click', () => {
  categoryButtons.forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  const selected = button.dataset.category;
  document.querySelectorAll('.profile-card').forEach(card => {
    card.hidden = selected !== 'सभी' && card.dataset.kind !== selected;
  });
}));

document.getElementById('profileForm').addEventListener('submit', event => {
  event.preventDefault();
  const name = document.getElementById('name').value.trim();
  const kind = document.getElementById('kind').value;
  const interest = document.getElementById('interest').value.trim();
  const card = document.createElement('article');
  card.className = 'profile-card';
  card.dataset.kind = kind;
  card.innerHTML = `<div class="avatar green">🙂</div><h3></h3><p></p><span class="tag"></span>`;
  card.querySelector('h3').textContent = name;
  card.querySelector('p').textContent = interest;
  card.querySelector('.tag').textContent = kind;
  document.getElementById('profiles').prepend(card);
  document.getElementById('formMessage').textContent = 'आपकी डेमो प्रोफ़ाइल इस पेज पर जोड़ दी गई है।';
  event.target.reset();
});

document.querySelectorAll('.tool').forEach(button => button.addEventListener('click', () => {
  document.getElementById('toolMessage').textContent = button.dataset.message;
}));
document.getElementById('loginBtn').addEventListener('click', () => {
  alert('लॉगिन सुविधा अगले संस्करण में जोड़ी जाएगी।');
});
document.querySelectorAll('.contact').forEach(button => button.addEventListener('click', () => {
  alert('यह एक डेमो प्रोफ़ाइल है। अभी असली संपर्क सुविधा उपलब्ध नहीं है।');
}));
